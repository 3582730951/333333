# 八项生产问题审计与渐进式改造计划（2026-07-31）

## 0. 基线与边界

- 基线提交：`a14151d862aaf74d21d68f759ab6b2aecd0f2744`
- 运行形态：Go 单体 API/调度服务 + React/Vite 管理端 + SQLite/PostgreSQL 存储 + systemd/容器部署脚本。
- 本轮只处理用户反馈的八项问题；保留现有 HTTP 路径、旧供应商字段、账户数据和安装目录约定。
- 基线文件哈希：`artifacts/eight-issue-fix-20260731/baseline-files.sha256`。
- 实施原则：兼容读取、规范写入；添加式数据库迁移；每批独立测试；最终提供正向补丁、验证记录和可执行回滚。

## 1. 架构与关键链路

```mermaid
flowchart LR
  U[Browser / downstream client] --> SPA[React SPA]
  U --> API[Go HTTP adapters]
  SPA --> API
  API --> AUTH[downstream auth / policy]
  API --> ROUTE[routing + affinity + scheduler]
  ROUTE --> STORE[(SQLite / PostgreSQL)]
  ROUTE --> UP[Codex / custom upstream]
  API --> AUTO[registration + team lifecycle]
  AUTO --> MAIL[mailbox adapter]
  AUTO --> REG[node registrar]
  INST[install.sh / update.sh] --> REL[immutable release + current symlink]
  REL --> API
  REL --> SPA
```

| 层 | 主要位置 | 当前职责 | 本轮变更 |
|---|---|---|---|
| UI 表现层 | `web-spa/src` | 管理页面、表单、契约解析 | 邮件兼容适配、可靠复制、多路径编辑器、配置向导 |
| HTTP 适配层 | `internal/api` | 管理 API、协议转换、上游调用 | 路径选择、下游隔离、就绪信息 |
| 核心调度层 | `internal/routing`, `internal/scheduler` | 亲和键、账号/出口租约 | 在保持原亲和语义的同时加入下游命名空间 |
| 基础设施层 | `internal/storage` | SQLite/PostgreSQL 与迁移 | `routes_json` 添加式迁移；取消新库示例供应商种子 |
| 自动化扩展 | `services`, `workers` | 注册、邮箱、团队生命周期 | 提供可运行的 Cloudflare 邮箱适配器与教程 |
| 发布部署 | `install.sh`, `update.sh`, `scripts` | 首装、更新、快照、A/B 发布 | 自动识别更新；快照去重和有界轮转；清理受管旧文件 |

### 自定义供应商请求数据流

```mermaid
sequenceDiagram
  participant D as Downstream key
  participant H as HTTP adapter
  participant R as Route resolver
  participant S as Scheduler
  participant U as Upstream
  D->>H: /v1/chat/completions or /v1/responses or /v1/messages
  H->>R: provider + downstream path
  R-->>H: effective base_url/protocol/profile + route_id
  H->>H: namespace affinity with downstream identity
  H->>S: isolated affinity + route group
  S-->>H: account/egress lease
  H->>U: converted request using selected route
  U-->>H: response
  H-->>D: compatible downstream response
```

### 安装/更新目标流程

```mermaid
flowchart TD
  A[run root install.sh] --> B{existing managed install?}
  B -- no --> C[fresh install]
  B -- yes --> D[delegate to update.sh]
  D --> E[SQLite online backup]
  E --> F{same content as newest?}
  F -- yes --> G[reuse newest snapshot]
  F -- no --> H[compressed snapshot]
  G --> I[age/count/byte pruning]
  H --> I
  I --> J[build immutable staged release]
  J --> K[health check + atomic current switch]
  K --> L[retain current + one previous release]
```

## 2. 问题证据、根因与兼容方案

| # | 现象 | 代码证据 / 根因 | 改造方案 | 风险与验证 |
|---|---|---|---|---|
| 1 | 邮箱池仍报告“无法识别的数据” | `features/accounts/api/emailPool.ts` 只接受单一对象形状，且行时间戳为必填数值；旧响应数组、`data/items/rows` 包装、`page_size`、空时间戳都会落入 `contracts.ts` 的通用错误 | 在功能边界增加兼容适配器，接受已知旧形状并统一成规范对象；错误对象仍拒绝；测试每种历史形状 | 过度宽松会吞掉服务端错误。测试必须证明 `{error: ...}` 和 HTML 仍失败 |
| 2 | 授权链接复制按钮无效 | `OAuthLoginModal.jsx` 依赖 `writeClipboard`；旧实现只在安全上下文尝试 Clipboard API，降级依赖已废弃的 `execCommand`，失败时没有选择可见文本；按钮也缺少可访问名称 | 同一用户手势内执行同步降级；保留/恢复焦点与选择；最终失败时自动选中可见 URL；增加文字/ARIA 与成功、降级、失败测试 | 浏览器差异。以 Clipboard API、非安全上下文和两者失败三条测试覆盖 |
| 3 | `install.sh` 更新覆盖不完整，恢复后备份堆积 | 根入口总是走首装脚本；更新备份默认保留 10 份且相同 DB 每次再生成；旧版源文件叠加解压后可残留 | 根入口识别已安装实例并转更新；快照内容去重并按数量/年龄/总字节三重上限轮转；发布仍用不可变目录和原子切换；仅清理明确受管的旧源文件 | 错判首装/更新和误删文件风险。用临时目录模拟首装、旧安装、相同/不同快照及保留边界 |
| 4 | 首装出现 DeepSeek/SiliconFlow | SQLite 与 PostgreSQL 初始化路径显式插入两条示例供应商 | 删除新库种子；迁移只清理“字段仍等于历史默认且未被账号引用”的旧种子，保留用户改过或在用的配置 | 误删用户配置风险。精确匹配 + 引用保护；测试新库为空、原样种子清理、修改/引用配置保留 |
| 5 | 一个供应商不能配置多条调用路径 | `CustomProvider` 只有一个 `BaseURL/UpstreamProtocol/TransportProfile`，三个下游入口共享它 | 保留旧字段作为默认路由，新增 `routes_json`；按下游路径选择覆盖项；管理端提供可增删的路径卡片 | 数据兼容风险低（默认 `[]`）。存储 round-trip、API 校验、三协议路由集成测试 |
| 6 | 多下游上下文串线 | 自定义供应商亲和键直接使用 thread/conversation/resource 标识；不同下游密钥可产生相同哈希；Cookie jar key 也未含下游与有效路由 | 从鉴权上下文派生稳定下游作用域，重新命名空间化亲和键；Cookie jar 同时包含下游作用域与路由指纹 | 变更会重新建立旧绑定，但防止跨租户复用。测试不同 key 隔离、同 key 稳定、开放模式确定性 |
| 7 | 自动注册/团队/住宅 IP/CF 邮箱缺少可复制教程 | 页面仅有字段和少量步骤，仓库无完整 CF 邮件 Worker 适配器 | 增加仓库内可部署 Worker、SQL、Wrangler 配置和脚本；编写端到端运维教程；页面加入命令块复制按钮和字段示例 | 外部平台会变化。实现以官方接口为准，并在文档记录验证日期 |
| 8 | 团队生命周期配置难懂且前端信息不足 | 现有页面将 workspace、cycle、邮箱、注册等前置条件分散展示，高级字段与日常字段同层级 | 增加就绪清单、步骤化创建、字段说明、合理预设、前置条件跳转；后端统计返回可机器判断的 readiness | UI 回归风险。组件测试 + typecheck + 构建 + 路由/视觉契约检查 |

## 3. 冗余与耦合审计（本轮相关范围）

| 项目 | 位置 | 重复对象 | 等级 | 合并方式 |
|---|---|---|---|---|
| API 响应兼容解析分散 | 多个 SPA feature API | 各页面自行处理 envelope | 中 | 本轮在邮件域建立局部 adapter，不立即全局重写；后续提炼共用 envelope helper |
| 剪贴板调用反馈分散 | OAuth、教程代码块等 | `navigator.clipboard`/Toast 组合 | 中 | 统一进入 `browserClipboard.js`，页面只决定失败后的可见选择 |
| 自定义供应商协议分支 | `chat_custom.go` 多个 handler | 三个协议的 route 决策 | 高 | 新增纯函数 route resolver，在转换分支之前只解析一次；不改转换器 |
| 供应商建表/迁移双实现 | SQLite/PostgreSQL | schema 与加列逻辑 | 高 | 同步增加同名 JSON 列与共同规范化测试；本轮不替换数据库抽象 |
| 部署说明分散 | README、页面、脚本 | 参数名和示例可能漂移 | 中 | 可运行示例作为单一事实来源，页面/文档链接并复制相同命令 |

耦合矩阵：

| from \ to | SPA 契约 | API adapter | routing | storage | deploy |
|---|---:|---:|---:|---:|---:|
| SPA | 低 | 高 | 低 | 低 | 中 |
| API adapter | 低 | — | 高 | 高 | 低 |
| routing | 低 | 中 | — | 中 | 低 |
| storage | 低 | 低 | 低 | — | 中 |
| deploy | 中 | 中 | 低 | 高 | — |

本轮通过边界适配器、纯 route resolver、添加式迁移和可运行部署模板降低耦合；不做跨层推倒重写。

## 4. 稳定性、资源与观测结论

- **已确认**：重复 SQLite 快照导致磁盘随更新/恢复次数线性增长；默认保留数量过大且没有总字节上限。
- **已确认**：未命名空间化的对话亲和键允许两个下游凭据命中同一账户/出口/Cookie jar。
- **已确认**：严格前端 schema 把可恢复的旧数据形状升级成整个页面故障。
- **高概率**：旧源覆盖安装会保留新版清单之外的受管文件；不可变运行 release 本身仅保留 current/previous，主要风险在构建源树和 DB 快照。
- **继续观测**：注册吞吐、Cloudflare 邮件延迟、团队补员成功率；没有生产指标时不宣称性能提升。

需要保留/新增的观测字段：请求 ID、provider route ID、下游作用域的不可逆短哈希、快照复用/删除数量、生命周期 readiness 原因。日志不得输出密钥、完整邮件令牌或代理密码。

## 5. 目标结构与分阶段路线

### P0：用户可见故障与数据安全

1. 邮件响应兼容层 + 错误边界测试。
2. 复制 helper + OAuth 可见失败恢复。
3. 安装入口识别 + 快照去重/三重轮转。
4. 取消示例供应商种子并安全迁移。

### P1：供应商路由与租户隔离

1. `routes_json` 添加式迁移、模型和 CRUD。
2. 下游路径 resolver，旧单路径字段继续作为 fallback。
3. 亲和键和 Cookie jar 的 downstream/route 命名空间。
4. 存储、管理 API 和请求路由回归。

### P1：可操作性

1. Cloudflare 邮箱 Worker 可运行示例。
2. 注册、住宅出口、邮箱、团队生命周期逐步教程。
3. 前端 readiness 清单、简单/高级分层、复制命令。

### 验证与回滚门禁

- 每一批先跑定向测试，再跑 `go test ./...`、SPA `typecheck/test/build/check` 和安装脚本测试。
- 数据库迁移只加列；旧二进制忽略新列。路由数组为空时行为与基线一致。
- 根安装脚本提供显式首装覆盖开关，自动识别结果写日志。
- 最终产物：`modified-source.tar.gz`、`complete.patch`、`verification.md`、`rollback.sh`；回滚脚本在临时工作树实际执行并校验基线哈希。

## 6. 最终实施完成矩阵（2026-08-01）

| # | 最终行为 | 权威证据 | 状态 |
|---|---|---|---|
| 1 | 邮箱 API 接受历史数组、`data/items/rows`、snake/camel 分页和空时间；明确错误/HTML 仍被拒绝并保留 request ID | `web-spa/tests/contracts.test.ts`、`internal/api/mailbox_config_test.go` | 完成 |
| 2 | OAuth 链接优先 Clipboard API，同一手势同步降级，最后自动选中可见 URL 以便手工复制 | `browser-clipboard.test.ts`、`oauth-copy.test.tsx` | 完成 |
| 3 | 已安装目标自动转更新；SQLite 快照去重并按数量/年龄/字节上限轮转；受管源文件与哈希资源收敛 | `scripts/test-upgrade-safety.sh`，943 文件幂等清单且已删除路径为 0 | 完成 |
| 4 | 新 SQLite/PostgreSQL 不再写入 DeepSeek/SiliconFlow；旧默认且未引用项安全清理，用户修改/已引用项保留 | `custom_provider_seed_test.go` 与全仓 Go 测试 | 完成 |
| 5 | 供应商保留旧默认路由，新增多路径 JSON；Chat/Responses/Messages 按下游入口选择有效 URL/协议/传输配置 | `custom_provider_multi_route_test.go`、`custom_provider_routes_test.go`、`provider-routes.test.ts` | 完成 |
| 6 | 亲和键和 Cookie jar 同时纳入下游作用域与有效路由指纹；同 key 稳定，不同 key 隔离 | `custom_provider_passthrough_test.go`及 API 全包测试 | 完成 |
| 7 | 仓库内 Worker、D1 migration、Wrangler 模板、部署脚本与端到端复制粘贴手册已交付；注册/住宅 IP/CF 页有可复制命令 | Worker 4/4 contract tests，`docs/operations/AUTOMATION_AND_TEAM_LIFECYCLE.md` | 完成 |
| 8 | Team Lifecycle 返回可机读 readiness，前端改为顺序就绪清单、预设与日常/高级分层 | `team_lifecycle_test.go`、`team-lifecycle-presentation.test.tsx`、最终视觉回归 | 完成 |

全局验收：

- `/root/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.25.12.linux-amd64/bin/go test ./...`：退出 0，全部 Go 包通过。
- `npm --prefix web-spa run verify`：退出 0，21 测试文件 / 100 测试通过并完成生产构建。
- `npm --prefix web-spa run test:e2e`：退出 0，54/54 通过，含 11 个 WCAG A/AA 页面。
- `npm --prefix web-spa run capture:ui-review`：退出 0，240/240 页面组合、0 失败、0 重叠/越界/裁切。
- `npm --prefix deploy/cloudflare-mailbox test`：退出 0，4/4 通过。
- `bash scripts/test-upgrade-safety.sh`：退出 0，安装分派、有界备份与受管源收敛通过。

最终可复核证据位于 `artifacts/eight-issue-fix-20260731/`；修改包、完整补丁、验证记录与回滚脚本在交付时由 SHA-256 清单锁定。
