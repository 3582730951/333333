# 自动注册、住宅 IP、自建邮箱与 Team 生命周期：复制粘贴手册

本文只使用仓库当前实现的接口和字段。所有大写值都是需要替换的占位符。通过 Bearer Admin Token 调用时不需要浏览器 CSRF Header。

## 0. 更新已有安装

安装目录中已有 `config.json`、数据库或 systemd 服务时，根目录 `install.sh` 会自动进入保守更新流程：先备份，再只更新仓库托管文件，最后按数量、年龄和总字节数清理旧备份。业务配置、数据和插件目录保留。

```bash
cd /PATH/TO/codex-account-pool
./install.sh
```

显式选择更新，或确实需要全新安装：

```bash
./install.sh --update
./install.sh --fresh-install
```

## 1. 启用注册器

先备份并修改实际配置文件；默认协议引擎使用邮箱 OTP：

```bash
cd /PATH/TO/codex-account-pool
cp -a config.json "config.json.before-registration.$(date +%s)"
jq '.registration_enabled = true
  | .default_register_method = "protocol_v2"
  | .registration_concurrency = 1
  | .registration_timeout = 300' config.json > config.json.tmp
mv config.json.tmp config.json
sudo systemctl restart codex-account-pool
```

服务名不同就替换最后一行。之后设置后续命令共用变量：

```bash
export POOL_URL='https://POOL_HOST'
export ADMIN_TOKEN='ADMIN_TOKEN'
```

## 2. 接入住宅代理并建立注册池

把完整代理 URL 放入环境变量，避免写入 shell history；支持 HTTP(S)、SOCKS5(H) 以及 UI 展示的几种无 scheme 格式。

```bash
read -rsp 'Residential proxy URL: ' RESIDENTIAL_PROXY_URL; echo
export RESIDENTIAL_PROXY_URL

curl -fsS -X POST "$POOL_URL/admin/egress-profiles" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H 'Content-Type: application/json' \
  --data "$(jq -n --arg endpoint "$RESIDENTIAL_PROXY_URL" '{
    id:"egress_residential_registration",
    name:"Registration residential",
    type:"http_proxy",
    endpoint:$endpoint,
    region:"US",
    ip_mode:"dynamic_residential",
    provider_key:"residential",
    max_concurrency:1,
    detect_region:true
  }')"

curl -fsS -X POST "$POOL_URL/admin/egress-pools" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H 'Content-Type: application/json' \
  --data '{"id":"pool_registration_residential","name":"Registration residential","purpose":"registration","assignment_strategy":"sticky_least_used"}'

curl -fsS -X POST "$POOL_URL/admin/egress-pools/pool_registration_residential/members" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H 'Content-Type: application/json' \
  --data '{"egress_id":"egress_residential_registration","enabled":true,"capacity":1}'

curl -fsS -X POST "$POOL_URL/admin/settings-center" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H 'Content-Type: application/json' \
  --data '[{"section":"config","values":{"registration_egress_pool_id":"pool_registration_residential"}}]'
```

在 **出口 / 代理** 页面点击该出口的“编辑 → 测试连接”，确认出口 IP 和国家符合预期。动态住宅服务需要一任务一 SID 时，把服务商要求的 SID 放在代理用户名或其动态配置中，并将并发保持为 `1`。

## 3. 部署 Cloudflare 自建邮箱

仓库内 Worker 已实现本项目所需的创建地址、JWT 邮箱读取、Email Routing handler、D1 迁移和过期清理：

```bash
cd /PATH/TO/codex-account-pool/deploy/cloudflare-mailbox
npx wrangler login
MAIL_DOMAIN=mail.example.com \
API_HOST=mailbox-api.example.com \
./deploy.sh
```

脚本结束后，在 Cloudflare Dashboard 打开 **Email Routing → Routing rules → Catch-all address**，Action 选择 **Send to a Worker**，目标选择脚本部署的 Worker。保存脚本最后显示的 Admin Token。

将 Worker 接入账号池并同时设为注册、Team 默认：

```bash
export MAILBOX_API_URL='https://mailbox-api.example.com'
export MAIL_DOMAIN='mail.example.com'
read -rsp 'Mailbox admin token: ' MAILBOX_ADMIN_TOKEN; echo
export MAILBOX_ADMIN_TOKEN

MAILBOX_SAVE="$(curl -fsS -X POST "$POOL_URL/admin/email-pool/cloudflare" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H 'Content-Type: application/json' \
  --data "$(jq -n \
    --arg api "$MAILBOX_API_URL" --arg domain "$MAIL_DOMAIN" --arg token "$MAILBOX_ADMIN_TOKEN" '{
      display_name:("Cloudflare · " + $domain), api_url:$api, domain:$domain,
      admin_token:$token, enabled:true,
      default_for_registration:true, default_for_team:true
    }')")"
printf '%s\n' "$MAILBOX_SAVE" | jq
MAILBOX_PROVIDER_KEY="$(printf '%s' "$MAILBOX_SAVE" | jq -r .provider_key)"

curl -fsS -X POST "$POOL_URL/admin/email-pool/cloudflare/test" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H 'Content-Type: application/json' \
  --data "$(jq -n --arg key "$MAILBOX_PROVIDER_KEY" '{provider_key:$key}')"
```

第二条也可以在 **邮箱池 → Cloudflare 自建邮箱** 点击“保存并检测”完成；页面会自动使用保存返回的 `provider_key`，无需手工拼接。

## 4. 检查并启动一个自动注册任务

Provider 凭据属于不同服务商，先在 **自动注册 → 凭据配置** 中粘贴对应密钥。随后复制检查命令：

```bash
curl -fsS "$POOL_URL/admin/register/readiness" \
  -H "Authorization: Bearer $ADMIN_TOKEN" | jq
```

按 `blockers` 清零并在页面完成单账号 canary 后启动一号任务：

```bash
curl -fsS -X POST "$POOL_URL/admin/register/batch" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H 'Content-Type: application/json' \
  --data '{
    "count":1,
    "method":"protocol_v2",
    "identity_mode":"email",
    "mailbox_provider":"",
    "registration_egress_pool_id":"pool_registration_residential"
  }' | jq
```

## 5. 建立 Team 空间并启动生命周期

先在账号池添加母号。母号必须为 active，带有效 Access Token 和 `upstream_account_id`。状态页会把每个缺项显示成可点击清单。

```bash
curl -fsS "$POOL_URL/admin/team-lifecycle/stats" \
  -H "Authorization: Bearer $ADMIN_TOKEN" | jq '.readiness'
```

创建 Team 空间；`workspace_ref`、邮箱域名和邮箱 Provider 默认从母号/团队默认设置自动读取：

```bash
curl -fsS -X POST "$POOL_URL/admin/team-lifecycle/workspaces" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H 'Content-Type: application/json' \
  --data '{
    "id":"teamws_primary",
    "name":"Primary Team rotation",
    "parent_account_id":"PARENT_ACCOUNT_ID",
    "max_members":10
  }' | jq
```

启动一个真实循环；默认额度剩余 `1%` 时轮换，失败最多重试 5 次。先审阅流程时把 `shadow_mode` 改为 `true`：

```bash
export IDEMPOTENCY_KEY="team-cycle-$(date +%s)"
curl -fsS -X POST "$POOL_URL/admin/team-lifecycle/workflows" \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Idempotency-Key: $IDEMPOTENCY_KEY" \
  -H 'Content-Type: application/json' \
  --data '{
    "workspace_id":"teamws_primary",
    "parent_account_id":"PARENT_ACCOUNT_ID",
    "child_account_id":"CHILD_ACCOUNT_ID_OR_EMAIL",
    "rotate_threshold_percent":1,
    "max_attempts":5,
    "shadow_mode":false
  }' | jq
```

## 6. 最终验收

```bash
curl -fsS "$POOL_URL/admin/register/readiness" -H "Authorization: Bearer $ADMIN_TOKEN" | jq '{ready,blockers,providers}'
curl -fsS "$POOL_URL/admin/team-lifecycle/stats" -H "Authorization: Bearer $ADMIN_TOKEN" | jq '{readiness,states}'
curl -fsS "$POOL_URL/admin/team-lifecycle/workflows?limit=20" -H "Authorization: Bearer $ADMIN_TOKEN" | jq '.items'
```

预期：注册 `blockers` 为空且 canary ready；Team `readiness.cycle_create_ready=true`；工作流从 `queued` 进入执行状态，并持续写入事件时间线。
