# Modified source artifact

Baseline: `a14151d862aaf74d21d68f759ab6b2aecd0f2744`

This archive contains the 121 files that exist after this delivery. The 49 removed baseline files are listed in `deleted-files.txt` and represented by `complete.patch`. Validate file bytes with `sha256sum -c DELIVERY-MANIFEST/source-sha256.txt`.
