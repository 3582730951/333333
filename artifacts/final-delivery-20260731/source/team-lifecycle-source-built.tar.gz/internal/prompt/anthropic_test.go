package prompt

import (
	"encoding/json"
	"reflect"
	"strconv"
	"strings"
	"testing"
)

func TestChatCompletionToAnthropic(t *testing.T) {
	raw := []byte(`{"model":"claude-sonnet-4-6","messages":[{"role":"system","content":"be brief"},{"role":"user","content":"hi"}],"temperature":0.5,"stream":true}`)
	out, err := ChatCompletionToAnthropic(raw)
	if err != nil {
		t.Fatal(err)
	}
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	if m["system"] != "be brief" {
		t.Fatalf("system hoist: %v", m["system"])
	}
	if m["max_tokens"] == nil {
		t.Fatalf("max_tokens must be set (Anthropic requires it)")
	}
	if m["stream"] != true {
		t.Fatalf("stream not carried: %v", m["stream"])
	}
	msgs, _ := m["messages"].([]interface{})
	if len(msgs) != 1 {
		t.Fatalf("system message should not remain in messages: %v", msgs)
	}
	first := msgs[0].(map[string]interface{})
	if first["role"] != "user" || first["content"] != "hi" {
		t.Fatalf("converted message: %v", first)
	}
}

func TestAnthropicToChatCompletion(t *testing.T) {
	raw := []byte(`{"id":"msg_1","model":"claude-x","content":[{"type":"text","text":"hello"}],"stop_reason":"max_tokens","usage":{"input_tokens":10,"output_tokens":4}}`)
	out, err := AnthropicToChatCompletion(raw, "claude-x")
	if err != nil {
		t.Fatal(err)
	}
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	if m["object"] != "chat.completion" {
		t.Fatalf("object: %v", m["object"])
	}
	choice := m["choices"].([]interface{})[0].(map[string]interface{})
	if choice["finish_reason"] != "length" {
		t.Fatalf("finish_reason mapping: %v", choice["finish_reason"])
	}
	if choice["message"].(map[string]interface{})["content"] != "hello" {
		t.Fatalf("content: %v", choice["message"])
	}
	if m["usage"].(map[string]interface{})["total_tokens"].(float64) != 14 {
		t.Fatalf("total_tokens: %v", m["usage"])
	}
}

func TestChatToolsAndToolCallsConversion(t *testing.T) {
	raw := []byte(`{"model":"claude-x","tools":[{"type":"function","function":{"name":"get_weather","description":"w","parameters":{"type":"object","properties":{"city":{"type":"string"}}}}}],"tool_choice":"required","messages":[{"role":"user","content":"weather?"},{"role":"assistant","tool_calls":[{"id":"call_1","type":"function","function":{"name":"get_weather","arguments":"{\"city\":\"SF\"}"}}]},{"role":"tool","tool_call_id":"call_1","content":"sunny"}]}`)
	out, err := ChatCompletionToAnthropic(raw)
	if err != nil {
		t.Fatal(err)
	}
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	tool0 := m["tools"].([]interface{})[0].(map[string]interface{})
	if tool0["name"] != "get_weather" || tool0["input_schema"] == nil {
		t.Fatalf("function tool not converted to Anthropic shape: %v", tool0)
	}
	if tc, _ := m["tool_choice"].(map[string]interface{}); tc["type"] != "any" {
		t.Fatalf("tool_choice required→any: %v", m["tool_choice"])
	}
	msgs := m["messages"].([]interface{})
	asst := msgs[1].(map[string]interface{})["content"].([]interface{})[0].(map[string]interface{})
	if asst["type"] != "tool_use" || asst["name"] != "get_weather" {
		t.Fatalf("assistant tool_calls→tool_use: %v", asst)
	}
	if inp, _ := asst["input"].(map[string]interface{}); inp["city"] != "SF" {
		t.Fatalf("tool_use input not parsed: %v", asst["input"])
	}
	tr := msgs[2].(map[string]interface{})["content"].([]interface{})[0].(map[string]interface{})
	if tr["type"] != "tool_result" || tr["tool_use_id"] != "call_1" {
		t.Fatalf("tool message→tool_result: %v", tr)
	}
}

func TestChatCompletionToAnthropicPreservesMultimodalContent(t *testing.T) {
	raw := []byte(`{"model":"claude-x","messages":[{"role":"user","content":[{"type":"text","text":"look"},{"type":"image_url","image_url":{"url":"data:image/png;base64,AAAA"}},{"type":"image_url","image_url":{"url":"https://example.com/cat.jpg"}},{"type":"file","file":{"file_data":"data:application/pdf;base64,JVBERi0="}}]}]}`)
	out, err := ChatCompletionToAnthropic(raw)
	if err != nil {
		t.Fatal(err)
	}
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	msgs := m["messages"].([]interface{})
	blocks, ok := msgs[0].(map[string]interface{})["content"].([]interface{})
	if !ok {
		t.Fatalf("multimodal content should be converted to Anthropic blocks, got %T: %v", msgs[0].(map[string]interface{})["content"], msgs[0].(map[string]interface{})["content"])
	}
	if blocks[0].(map[string]interface{})["text"] != "look" {
		t.Fatalf("text block not preserved: %v", blocks[0])
	}
	imgData := blocks[1].(map[string]interface{})
	if imgData["type"] != "image" {
		t.Fatalf("data image not converted: %v", imgData)
	}
	imgDataSrc := imgData["source"].(map[string]interface{})
	if imgDataSrc["type"] != "base64" || imgDataSrc["media_type"] != "image/png" || imgDataSrc["data"] != "AAAA" {
		t.Fatalf("data image source = %v", imgDataSrc)
	}
	imgURL := blocks[2].(map[string]interface{})["source"].(map[string]interface{})
	if imgURL["type"] != "url" || imgURL["url"] != "https://example.com/cat.jpg" {
		t.Fatalf("url image source = %v", imgURL)
	}
	doc := blocks[3].(map[string]interface{})
	if doc["type"] != "document" {
		t.Fatalf("file not converted to document: %v", doc)
	}
	docSrc := doc["source"].(map[string]interface{})
	if docSrc["type"] != "base64" || docSrc["media_type"] != "application/pdf" || docSrc["data"] != "JVBERi0=" {
		t.Fatalf("document source = %v", docSrc)
	}
}

func TestEnsureAnthropicCacheControl(t *testing.T) {
	// Compat-converted body: plain-string system + plain-string user content with
	// no cache_control anywhere → should gain a breakpoint at the system tail.
	// The latest user turn is volatile and must not be marked as a fallback; doing so
	// creates cache writes that rarely turn into reads when the next question differs.
	raw := []byte(`{"model":"claude-x","system":"big system","max_tokens":1024,"messages":[{"role":"user","content":"hello"}]}`)
	out := EnsureAnthropicCacheControl(raw, "")
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	sys, ok := m["system"].([]interface{})
	if !ok || len(sys) == 0 || sys[0].(map[string]interface{})["cache_control"] == nil {
		t.Fatalf("no cache_control on system tail: %v", m["system"])
	}
	if content := m["messages"].([]interface{})[0].(map[string]interface{})["content"]; content != "hello" {
		t.Fatalf("latest user turn should remain unmarked and unchanged: %v", content)
	}
	diag := InspectAnthropicCacheControl(out)
	if diag.BreakpointCount != 1 || diag.LatestUserCacheControl {
		t.Fatalf("cache diagnostics = %+v, want one stable marker and no latest-user marker", diag)
	}

	// A body already at the 4-breakpoint limit must still shed volatile latest-user
	// markers and never exceed the upstream limit.
	full := []byte(`{"system":[{"type":"text","text":"s","cache_control":{"type":"ephemeral"}}],"messages":[{"role":"user","content":[{"type":"text","text":"a","cache_control":{"type":"ephemeral"}},{"type":"text","text":"b","cache_control":{"type":"ephemeral"}},{"type":"text","text":"c","cache_control":{"type":"ephemeral"}}]}]}`)
	if n := cacheControlCount(t, EnsureAnthropicCacheControl(full, "")); n != 1 {
		t.Fatalf("latest-user markers should be stripped, got %d remaining breakpoints", n)
	}

	// The extended (1h) TTL is propagated onto injected breakpoints.
	out3 := EnsureAnthropicCacheControl([]byte(`{"system":"s","messages":[{"role":"user","content":"x"}]}`), "1h")
	if !strings.Contains(string(out3), `"ttl":"1h"`) {
		t.Fatalf("1h ttl not applied: %s", out3)
	}
}

func TestEnsureAnthropicCacheControlDoesNotMarkSingleVolatileUserTurn(t *testing.T) {
	raw := []byte(`{"model":"claude-x","messages":[{"role":"user","content":"latest volatile user turn"}]}`)
	out := EnsureAnthropicCacheControl(raw, "1h")
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	if got := cacheControlCount(t, out); got != 0 {
		t.Fatalf("single volatile user turn should not create cache writes, got %d markers: %s", got, out)
	}
	if content := m["messages"].([]interface{})[0].(map[string]interface{})["content"]; content != "latest volatile user turn" {
		t.Fatalf("latest user turn should remain unchanged: %v", content)
	}
}

func TestEnsureAnthropicCacheControlNormalizesTTLOrder(t *testing.T) {
	raw := []byte(`{"tools":[{"name":"Bash","input_schema":{"type":"object"},"cache_control":{"type":"ephemeral"}}],"system":[{"type":"text","text":"stable","cache_control":{"type":"ephemeral","ttl":"1h"}}],"messages":[{"role":"user","content":[{"type":"text","text":"hello","cache_control":{"type":"ephemeral","ttl":"1h"}}]},{"role":"assistant","content":[{"type":"text","text":"answer"}]},{"role":"user","content":[{"type":"text","text":"latest"}]}]}`)
	out := EnsureAnthropicCacheControl(raw, "")
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	sys := m["system"].([]interface{})[0].(map[string]interface{})
	if _, has := sys["cache_control"].(map[string]interface{})["ttl"]; has {
		t.Fatalf("system ttl should be downgraded after an earlier default/5m marker: %v", sys)
	}
	msg := m["messages"].([]interface{})[0].(map[string]interface{})
	block := msg["content"].([]interface{})[0].(map[string]interface{})
	if _, has := block["cache_control"].(map[string]interface{})["ttl"]; has {
		t.Fatalf("message ttl should be downgraded after an earlier default/5m marker: %v", block)
	}
}

func TestEnsureAnthropicCacheControlUpgradesExistingMarkersToOneHour(t *testing.T) {
	raw := []byte(`{"tools":[{"name":"Bash","input_schema":{"type":"object"},"cache_control":{"type":"ephemeral"}}],"system":[{"type":"text","text":"stable system","cache_control":{"type":"ephemeral"}}],"messages":[{"role":"user","content":[{"type":"text","text":"stable previous request","cache_control":{"type":"ephemeral"}}]},{"role":"assistant","content":[{"type":"text","text":"answer"}]},{"role":"user","content":[{"type":"text","text":"latest request"}]}]}`)
	out := EnsureAnthropicCacheControl(raw, "1h")
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	if n := cacheControlCount(t, out); n != 3 {
		t.Fatalf("cache marker count = %d, want existing three retained: %s", n, out)
	}
	assertAllCacheControlsHaveTTL(t, m["tools"], "tools")
	assertAllCacheControlsHaveTTL(t, m["system"], "system")
	msgs := m["messages"].([]interface{})
	assertAllCacheControlsHaveTTL(t, msgs[0].(map[string]interface{})["content"], "previous user")
	if got := msgs[2].(map[string]interface{})["content"].([]interface{})[0].(map[string]interface{})["text"]; got != "latest request" {
		t.Fatalf("latest request text changed: %v", got)
	}
}

func TestEnsureAnthropicCacheControlStripsLatestUserVolatileMarkers(t *testing.T) {
	raw := []byte(`{"model":"claude","messages":[{"role":"user","content":[{"type":"text","text":"<system-reminder>\nAs you answer the user's questions, you can use the following context:\n# repo\nstable\n</system-reminder>\n\n","cache_control":{"type":"ephemeral"}},{"type":"text","text":"real user request","cache_control":{"type":"ephemeral"}},{"type":"tool_result","tool_use_id":"toolu_1","content":"tool output","cache_control":{"type":"ephemeral"}}]}]}`)
	out := EnsureAnthropicCacheControl(raw, "1h")
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	blocks := m["messages"].([]interface{})[0].(map[string]interface{})["content"].([]interface{})
	if cc, ok := blocks[0].(map[string]interface{})["cache_control"].(map[string]interface{}); !ok || cc["ttl"] != "1h" {
		t.Fatalf("latest auto-context marker should be retained and upgraded: %v", blocks[0])
	}
	if _, has := blocks[1].(map[string]interface{})["cache_control"]; has {
		t.Fatalf("latest real user request marker should be stripped: %v", blocks[1])
	}
	if _, has := blocks[2].(map[string]interface{})["cache_control"]; has {
		t.Fatalf("latest tool_result marker should be stripped: %v", blocks[2])
	}
	if blocks[1].(map[string]interface{})["text"] != "real user request" || blocks[2].(map[string]interface{})["content"] != "tool output" {
		t.Fatalf("latest user content changed: %v", blocks)
	}
	diag := InspectAnthropicCacheControl(out)
	if !diag.LatestUserAutoContextCacheControl || diag.LatestUserTailCacheControl || diag.LatestUserToolResultCacheControl {
		t.Fatalf("latest-user diagnostics = %+v, want only auto-context marked", diag)
	}
}

func TestEnsureAnthropicCacheControlStripsLatestPlainUserMarkers(t *testing.T) {
	raw := []byte(`{"model":"claude","messages":[{"role":"user","content":[{"type":"image","source":{"type":"base64","media_type":"image/png","data":"abc"},"cache_control":{"type":"ephemeral"}},{"type":"text","text":"final question","cache_control":{"type":"ephemeral"}}]}]}`)
	out := EnsureAnthropicCacheControl(raw, "1h")
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	blocks := m["messages"].([]interface{})[0].(map[string]interface{})["content"].([]interface{})
	for i, block := range blocks {
		if _, has := block.(map[string]interface{})["cache_control"]; has {
			t.Fatalf("latest plain user block %d should not carry cache_control: %v", i, block)
		}
	}
	if blocks[0].(map[string]interface{})["source"].(map[string]interface{})["data"] != "abc" || blocks[1].(map[string]interface{})["text"] != "final question" {
		t.Fatalf("latest plain user content changed: %v", blocks)
	}
}

func TestEnsureAnthropicCacheControlPreservesExistingMarker(t *testing.T) {
	raw := []byte(`{"system":[{"type":"text","text":"stable","cache_control":{"type":"ephemeral","ttl":"1h"}}],"messages":[{"role":"user","content":"hello"}]}`)
	out := EnsureAnthropicCacheControl(raw, "")
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	sys := m["system"].([]interface{})
	cc := sys[0].(map[string]interface{})["cache_control"].(map[string]interface{})
	if cc["ttl"] != "1h" {
		t.Fatalf("existing client marker was overwritten: %v", cc)
	}
	if n := cacheControlCount(t, out); n > 4 {
		t.Fatalf("must not exceed 4 breakpoints, got %d", n)
	}
}

func TestEnsureAnthropicCacheControlMarksToolsBeforeVolatileLastUser(t *testing.T) {
	raw := []byte(`{"system":"stable system","tools":[{"name":"Bash","input_schema":{"type":"object"}},{"name":"Read","input_schema":{"type":"object"}}],"messages":[{"role":"user","content":"latest volatile user turn"}]}`)
	out := EnsureAnthropicCacheControl(raw, "")
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	tools := m["tools"].([]interface{})
	if _, ok := tools[len(tools)-1].(map[string]interface{})["cache_control"]; !ok {
		t.Fatalf("tool tail should carry a stable-prefix breakpoint: %v", tools[len(tools)-1])
	}
	content := m["messages"].([]interface{})[0].(map[string]interface{})["content"]
	if content != "latest volatile user turn" {
		t.Fatalf("last volatile user turn should remain unmarked and unchanged: %v", content)
	}
	if n := cacheControlCount(t, out); n != 2 {
		t.Fatalf("cache marker count = %d, want system+tools only", n)
	}
}

func TestEnsureAnthropicCacheControlMarksNativeClaudeStablePrefixes(t *testing.T) {
	raw := []byte(`{"model":"claude","system":[` +
		`{"type":"text","text":"x-anthropic-billing-header: cc_version=2.1.159.abc; cc_entrypoint=cli; cch=12345;"},` +
		`{"type":"text","text":"You are Claude Code, Anthropic's official CLI for Claude."},` +
		`{"type":"text","text":"stable project instructions"}` +
		`],"tools":[{"name":"Bash","input_schema":{"type":"object"}},{"name":"Read","input_schema":{"type":"object"}}],` +
		`"messages":[` +
		`{"role":"user","content":[` +
		`{"type":"text","text":"<system-reminder>\nAs you answer the user's questions, you can use the following context:\n# repo\nstable files\n</system-reminder>\n\n"},` +
		`{"type":"text","text":"first real request"}]},` +
		`{"role":"assistant","content":[{"type":"text","text":"ok"}]},` +
		`{"role":"user","content":[{"type":"text","text":"different final question"}]}` +
		`]}`)
	out := EnsureAnthropicCacheControl(raw, "1h")
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	sys := m["system"].([]interface{})
	if _, has := sys[0].(map[string]interface{})["cache_control"]; has {
		t.Fatalf("billing block must not be marked: %v", sys[0])
	}
	if cc, ok := sys[2].(map[string]interface{})["cache_control"].(map[string]interface{}); !ok || cc["ttl"] != "1h" {
		t.Fatalf("last non-billing system block should be marked with 1h: %v", sys[2])
	}
	tools := m["tools"].([]interface{})
	if _, has := tools[0].(map[string]interface{})["cache_control"]; has {
		t.Fatalf("only last tool should be marked: %v", tools[0])
	}
	if cc, ok := tools[1].(map[string]interface{})["cache_control"].(map[string]interface{}); !ok || cc["ttl"] != "1h" {
		t.Fatalf("last tool should be marked with 1h: %v", tools[1])
	}
	msgs := m["messages"].([]interface{})
	firstBlocks := msgs[0].(map[string]interface{})["content"].([]interface{})
	if cc, ok := firstBlocks[0].(map[string]interface{})["cache_control"].(map[string]interface{}); !ok || cc["ttl"] != "1h" {
		t.Fatalf("native auto-context prefix should be marked with 1h: %v", firstBlocks[0])
	}
	if cc, ok := firstBlocks[1].(map[string]interface{})["cache_control"].(map[string]interface{}); !ok || cc["ttl"] != "1h" {
		t.Fatalf("second-to-last user turn should be marked with 1h: %v", firstBlocks[1])
	}
	lastBlocks := msgs[2].(map[string]interface{})["content"].([]interface{})
	if _, has := lastBlocks[0].(map[string]interface{})["cache_control"]; has {
		t.Fatalf("volatile final user turn must not be marked: %v", lastBlocks[0])
	}
	if n := cacheControlCount(t, out); n != 4 {
		t.Fatalf("cache marker count = %d, want tool+system+auto-context+history", n)
	}
}

func TestEnsureAnthropicCacheControlCoarseSafeSkipsUserHistoryBreakpoints(t *testing.T) {
	raw := []byte(`{"model":"claude","system":[` +
		`{"type":"text","text":"x-anthropic-billing-header: cc_version=2.1.159.abc; cc_entrypoint=cli; cch=12345;"},` +
		`{"type":"text","text":"stable project instructions"}` +
		`],"tools":[{"name":"Bash","input_schema":{"type":"object"}}],` +
		`"messages":[` +
		`{"role":"user","content":[` +
		`{"type":"text","text":"<system-reminder>\nAs you answer the user's questions, you can use the following context:\n# repo\nstable files\n</system-reminder>\n\n"},` +
		`{"type":"text","text":"first real request"}]},` +
		`{"role":"assistant","content":[{"type":"text","text":"ok"}]},` +
		`{"role":"user","content":[{"type":"text","text":"final volatile question"}]}` +
		`]}`)
	out := EnsureAnthropicCacheControlWithPolicy(raw, "1h", "coarse_safe")
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	if n := cacheControlCount(t, out); n != 2 {
		t.Fatalf("coarse_safe marker count = %d, want tool+system only: %s", n, out)
	}
	msgs := m["messages"].([]interface{})
	firstBlocks := msgs[0].(map[string]interface{})["content"].([]interface{})
	for _, idx := range []int{0, 1} {
		if _, has := firstBlocks[idx].(map[string]interface{})["cache_control"]; has {
			t.Fatalf("coarse_safe must not mark user/history block %d: %v", idx, firstBlocks[idx])
		}
	}
	lastBlocks := msgs[2].(map[string]interface{})["content"].([]interface{})
	if _, has := lastBlocks[0].(map[string]interface{})["cache_control"]; has {
		t.Fatalf("coarse_safe must not mark latest user block: %v", lastBlocks[0])
	}
}

func TestEnsureAnthropicCacheControlMaxHitWritesLatestTailWithinFour(t *testing.T) {
	raw := []byte(`{"model":"claude","thinking":{"type":"enabled","budget_tokens":4096},"tool_choice":{"type":"auto"},"system":[` +
		`{"type":"text","text":"x-anthropic-billing-header: cc_version=2.1.159.abc; cc_entrypoint=cli; cch=12345;"},` +
		`{"type":"text","text":"stable project instructions"}` +
		`],"tools":[{"name":"Bash","input_schema":{"type":"object"}},{"name":"Read","input_schema":{"type":"object"}}],` +
		`"messages":[` +
		`{"role":"user","content":[` +
		`{"type":"text","text":"<system-reminder>\nAs you answer the user's questions, you can use the following context:\n# repo\nstable files\n</system-reminder>\n\n"},` +
		`{"type":"text","text":"first real request"}]},` +
		`{"role":"assistant","content":[{"type":"text","text":"ok"}]},` +
		`{"role":"user","content":"latest real request with a long tool tail to write for the next turn"}` +
		`]}`)
	before := anthropicMessageTextSequence(t, raw)
	out := EnsureAnthropicCacheControlWithPolicy(raw, "1h", "max_hit")
	after := anthropicMessageTextSequence(t, out)
	if !reflect.DeepEqual(after, before) {
		t.Fatalf("max_hit changed message text sequence:\nbefore=%#v\nafter=%#v\nbody=%s", before, after, out)
	}
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	if m["model"] != "claude" || m["thinking"] == nil || m["tool_choice"] == nil {
		t.Fatalf("max_hit changed model/thinking/tool_choice: %v", m)
	}
	if n := cacheControlCount(t, out); n != 4 {
		t.Fatalf("max_hit marker count = %d, want 4: %s", n, out)
	}
	diag := InspectAnthropicCacheControl(out)
	if !diag.LatestUserTailCacheControl || !diag.LatestUserCacheControl || diag.LatestUserToolResultCacheControl {
		t.Fatalf("max_hit should write latest text tail only, got diagnostics %+v\n%s", diag, out)
	}
	if len(diag.Breakpoints) != 4 {
		t.Fatalf("expected four breakpoint diagnostics, got %+v", diag.Breakpoints)
	}
	for _, bp := range diag.Breakpoints {
		if bp.Section == "" || bp.Type == "" || bp.Hash == "" || bp.TokenEstimate <= 0 {
			t.Fatalf("breakpoint diagnostic missing metadata: %+v", bp)
		}
	}
	if diag.MaxPossibleCacheReadTokens <= 0 {
		t.Fatalf("max possible cache read tokens not estimated: %+v", diag)
	}
	sys := m["system"].([]interface{})
	if _, has := sys[0].(map[string]interface{})["cache_control"]; has {
		t.Fatalf("billing block must not carry cache_control: %v", sys[0])
	}
}

func TestEnsureAnthropicCacheControlMaxHitPrefersPreviousTurnForRollingRead(t *testing.T) {
	raw := []byte(`{"model":"claude","system":[{"type":"text","text":"stable system"}],` +
		`"tools":[{"name":"Bash","input_schema":{"type":"object"}}],"messages":[` +
		`{"role":"user","content":[` +
		`{"type":"text","text":"<system-reminder>\nAs you answer the user's questions, you can use the following context:\n# repo\nstable\n</system-reminder>\n\n"},` +
		`{"type":"text","text":"first request"}]},` +
		`{"role":"assistant","content":"first response"},` +
		`{"role":"user","content":"latest request"}]}`)
	before := anthropicMessageTextSequence(t, raw)
	out := EnsureAnthropicCacheControlWithOptions(raw, AnthropicCacheControlOptions{
		Policy: "max_hit", LatestTailWrite: true, PreferRecentTurnRead: true,
	})
	after := anthropicMessageTextSequence(t, out)
	if !reflect.DeepEqual(after, before) {
		t.Fatalf("rolling-read planning changed message text:\nbefore=%#v\nafter=%#v\nbody=%s", before, after, out)
	}
	if count := cacheControlCount(t, out); count != 4 {
		t.Fatalf("rolling-read marker count=%d, want tool+system+previous+latest: %s", count, out)
	}
	var root map[string]interface{}
	if err := json.Unmarshal(out, &root); err != nil {
		t.Fatal(err)
	}
	messages := root["messages"].([]interface{})
	previous := messages[0].(map[string]interface{})["content"].([]interface{})
	if _, marked := previous[0].(map[string]interface{})["cache_control"]; marked {
		t.Fatalf("early auto-context consumed the rolling-turn slot: %v", previous[0])
	}
	if _, marked := previous[len(previous)-1].(map[string]interface{})["cache_control"]; !marked {
		t.Fatalf("previous latest-user boundary was not recreated: %v", previous)
	}
	latest := messages[len(messages)-1].(map[string]interface{})["content"].([]interface{})
	if _, marked := latest[len(latest)-1].(map[string]interface{})["cache_control"]; !marked {
		t.Fatalf("current latest tail was not written for the next turn: %v", latest)
	}
}

func TestEnsureAnthropicCacheControlMaxHitAddsRollingAnchorPastTwentyBlocks(t *testing.T) {
	var b strings.Builder
	b.WriteString(`{"model":"claude","system":"stable system","messages":[`)
	for i := 0; i < 24; i++ {
		if i > 0 {
			b.WriteByte(',')
		}
		role := "user"
		if i%2 == 1 {
			role = "assistant"
		}
		b.WriteString(`{"role":"`)
		b.WriteString(role)
		b.WriteString(`","content":[{"type":"text","text":"history block `)
		b.WriteString(strconv.Itoa(i))
		b.WriteString(`"}]}`)
	}
	b.WriteString(`,{"role":"user","content":[{"type":"text","text":"latest request"}]}]}`)
	out := EnsureAnthropicCacheControlWithPolicy([]byte(b.String()), "1h", "max_hit")
	if n := cacheControlCount(t, out); n > 4 {
		t.Fatalf("max_hit marker count = %d, want <= 4: %s", n, out)
	}
	anchors := messageIndexesWithCacheControl(t, out)
	if len(anchors) < 2 {
		t.Fatalf("max_hit should include a rolling history anchor plus latest tail, got anchors %v in %s", anchors, out)
	}
	if last := anchors[len(anchors)-1]; last != 24 {
		t.Fatalf("latest user message should be the final write anchor, got anchors %v", anchors)
	}
	if prev := anchors[len(anchors)-2]; 24-prev > 20 {
		t.Fatalf("rolling anchor too far behind latest for 20-block lookback: anchors %v", anchors)
	}
}

func TestLosslessAnthropicBlockSplitPreservesTextBytes(t *testing.T) {
	raw := []byte(`{"model":"claude","messages":[{"role":"user","content":[{"type":"text","text":"<system-reminder>\nAs you answer the user's questions, you can use the following context:\n# repo\nstable\n</system-reminder>\n\nActual question"}]}]}`)
	before := anthropicMessageTextSequence(t, raw)
	out := LosslessSplitAnthropicTextBlocks(raw)
	after := anthropicMessageTextSequence(t, out)
	if !reflect.DeepEqual(after, before) {
		t.Fatalf("lossless split changed concatenated text:\nbefore=%#v\nafter=%#v\nbody=%s", before, after, out)
	}
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	blocks := m["messages"].([]interface{})[0].(map[string]interface{})["content"].([]interface{})
	if len(blocks) != 2 {
		t.Fatalf("lossless split should produce two text blocks, got %d: %v", len(blocks), blocks)
	}
}

func TestEnsureAnthropicCacheControlMarksSecondToLastUserTurn(t *testing.T) {
	raw := []byte(`{"model":"claude","messages":[` +
		`{"role":"user","content":"first stable question"},` +
		`{"role":"assistant","content":[{"type":"text","text":"answer"}]},` +
		`{"role":"user","content":"final volatile question"}` +
		`]}`)
	out := EnsureAnthropicCacheControl(raw, "")
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	msgs := m["messages"].([]interface{})
	firstBlocks := msgs[0].(map[string]interface{})["content"].([]interface{})
	if _, ok := firstBlocks[0].(map[string]interface{})["cache_control"]; !ok {
		t.Fatalf("second-to-last user turn should be marked: %v", firstBlocks[0])
	}
	if last := msgs[2].(map[string]interface{})["content"]; last != "final volatile question" {
		t.Fatalf("final user turn should remain unmarked and unchanged: %v", last)
	}
}

func anthropicMessageTextSequence(t *testing.T, body []byte) []string {
	t.Helper()
	var m map[string]interface{}
	if err := json.Unmarshal(body, &m); err != nil {
		t.Fatal(err)
	}
	var out []string
	for _, msg := range m["messages"].([]interface{}) {
		mm := msg.(map[string]interface{})
		switch c := mm["content"].(type) {
		case string:
			out = append(out, c)
		case []interface{}:
			var sb strings.Builder
			for _, item := range c {
				block, ok := item.(map[string]interface{})
				if !ok {
					continue
				}
				if txt, ok := block["text"].(string); ok {
					sb.WriteString(txt)
				}
				if txt, ok := block["content"].(string); ok {
					sb.WriteString(txt)
				}
			}
			out = append(out, sb.String())
		}
	}
	return out
}

func messageIndexesWithCacheControl(t *testing.T, body []byte) []int {
	t.Helper()
	var m map[string]interface{}
	if err := json.Unmarshal(body, &m); err != nil {
		t.Fatal(err)
	}
	var out []int
	for i, msg := range m["messages"].([]interface{}) {
		mm := msg.(map[string]interface{})
		if _, has := mm["cache_control"]; has {
			out = append(out, i)
			continue
		}
		blocks, _ := mm["content"].([]interface{})
		for _, item := range blocks {
			block, ok := item.(map[string]interface{})
			if !ok {
				continue
			}
			if _, has := block["cache_control"]; has {
				out = append(out, i)
				break
			}
		}
	}
	return out
}

func cacheControlCount(t *testing.T, body []byte) int {
	t.Helper()
	var m map[string]interface{}
	if err := json.Unmarshal(body, &m); err != nil {
		t.Fatal(err)
	}
	return countCacheControl(m["system"]) + countCacheControl(m["tools"]) + countCacheControlMessages(m["messages"])
}

func assertAllCacheControlsHaveTTL(t *testing.T, blocks interface{}, label string) {
	t.Helper()
	arr, ok := blocks.([]interface{})
	if !ok {
		t.Fatalf("%s is not a block list: %v", label, blocks)
	}
	for _, block := range arr {
		m, ok := block.(map[string]interface{})
		if !ok {
			continue
		}
		cc, has := m["cache_control"].(map[string]interface{})
		if !has {
			continue
		}
		if cc["ttl"] != "1h" {
			t.Fatalf("%s marker not upgraded to 1h: %v", label, cc)
		}
	}
}

func TestAnthropicToolUseToChatToolCalls(t *testing.T) {
	raw := []byte(`{"id":"msg_1","model":"claude-x","content":[{"type":"tool_use","id":"toolu_1","name":"get_weather","input":{"city":"SF"}}],"stop_reason":"tool_use","usage":{"input_tokens":5,"output_tokens":2}}`)
	out, err := AnthropicToChatCompletion(raw, "claude-x")
	if err != nil {
		t.Fatal(err)
	}
	var m map[string]interface{}
	if err := json.Unmarshal(out, &m); err != nil {
		t.Fatal(err)
	}
	choice := m["choices"].([]interface{})[0].(map[string]interface{})
	if choice["finish_reason"] != "tool_calls" {
		t.Fatalf("finish_reason: %v", choice["finish_reason"])
	}
	tc0 := choice["message"].(map[string]interface{})["tool_calls"].([]interface{})[0].(map[string]interface{})
	fn := tc0["function"].(map[string]interface{})
	if fn["name"] != "get_weather" || !strings.Contains(fn["arguments"].(string), "SF") {
		t.Fatalf("tool_use→tool_call: %v", tc0)
	}
}
