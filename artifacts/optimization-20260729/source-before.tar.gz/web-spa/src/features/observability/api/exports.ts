import api from '../../../api.js';

export type AuditExportKind = 'diagnostics' | 'cache-hits';

export interface AuditArchive {
  blob: Blob;
  filename: string;
}

export interface DiagnosticExportOptions {
  pollIntervalMs?: number;
  timeoutMs?: number;
  queuedStallMs?: number;
  wait?: (milliseconds: number) => Promise<void>;
  now?: () => number;
}

interface DiagnosticJob {
  id: string;
  status: string;
  download_url?: string;
  error_code?: string;
}

const archiveDefinitions: Record<Exclude<AuditExportKind, 'diagnostics'>, { endpoint: string; fallbackName: string }> = {
  'cache-hits': { endpoint: '/admin/export/cache-hits', fallbackName: 'codex-pool-cache-hits.zip' },
};

const diagnosticFallbackName = 'codex-pool-diagnostics.zip';
const diagnosticPollIntervalMs = 2_000;
const diagnosticTimeoutMs = 30 * 60 * 1_000;
const diagnosticQueuedStallMs = 60_000;
const pendingDiagnosticStatuses = new Set(['queued', 'snapshotting', 'rendering', 'validating']);
const runningDiagnosticStatuses = new Set(['snapshotting', 'rendering', 'validating']);
const terminalDiagnosticStatuses = new Set(['failed', 'cancelled', 'expired']);

export function filenameFromDisposition(value: unknown): string {
  const raw = String(value || '');
  const utf8 = raw.match(/filename\*=UTF-8''([^;]+)/i);
  if (utf8?.[1]) {
    const encoded = utf8[1].trim().replace(/^"|"$/g, '');
    try {
      return decodeURIComponent(encoded);
    } catch {
      return encoded;
    }
  }
  const plain = raw.match(/filename=([^;]+)/i);
  return plain?.[1]?.trim().replace(/^"|"$/g, '') || '';
}

function responseHeader(headers: unknown, name: string): string {
  if (!headers || typeof headers !== 'object') return '';
  const candidate = headers as Record<string, unknown> & { get?: (headerName: string) => unknown };
  if (typeof candidate.get === 'function') {
    const value = candidate.get(name);
    if (value != null) return String(value);
  }
  const value = candidate[name] ?? candidate[name.toLowerCase()];
  return value == null ? '' : String(value);
}

function diagnosticJobFromResponse(value: unknown): DiagnosticJob {
  if (!value || typeof value !== 'object') throw new Error('Invalid diagnostic job response.');
  const envelope = value as { job?: unknown };
  const raw = envelope.job && typeof envelope.job === 'object' ? envelope.job : value;
  const job = raw as Partial<DiagnosticJob>;
  const id = String(job.id || '').trim();
  const status = String(job.status || '').trim().toLowerCase();
  if (!/^diagjob_[A-Za-z0-9_-]+$/.test(id) || !status) {
    throw new Error('Invalid diagnostic job response.');
  }
  return {
    id,
    status,
    download_url: typeof job.download_url === 'string' ? job.download_url : undefined,
    error_code: typeof job.error_code === 'string' ? job.error_code : undefined,
  };
}

function diagnosticJobsFromListResponse(value: unknown): DiagnosticJob[] {
  if (!value || typeof value !== 'object') return [];
  const jobs = (value as { jobs?: unknown }).jobs;
  if (!Array.isArray(jobs)) return [];
  const parsed: DiagnosticJob[] = [];
  for (const candidate of jobs) {
    try {
      parsed.push(diagnosticJobFromResponse(candidate));
    } catch {
      // A malformed unrelated historical row must not strand the current export.
    }
  }
  return parsed;
}

async function zipBlobFromResponse(response: {
  data: unknown;
  headers?: unknown;
}, fallbackName: string): Promise<AuditArchive> {
  const contentType = responseHeader(response.headers, 'content-type').toLowerCase();
  if (!contentType.includes('application/zip') && !contentType.includes('application/octet-stream')) {
    throw new Error('The server did not return a diagnostic ZIP archive.');
  }
  const blob = response.data instanceof Blob
    ? response.data
    : new Blob([response.data as BlobPart], { type: 'application/zip' });
  if (blob.size < 4) throw new Error('The diagnostic ZIP archive is incomplete.');
  const signature = new Uint8Array(await blob.slice(0, 4).arrayBuffer());
  if (signature[0] !== 0x50 || signature[1] !== 0x4b) {
    throw new Error('The server returned an invalid diagnostic ZIP archive.');
  }
  const filename = filenameFromDisposition(responseHeader(response.headers, 'content-disposition')) || fallbackName;
  return { blob, filename };
}

async function fetchDirectArchive(
  endpoint: string,
  fallbackName: string,
): Promise<AuditArchive> {
  const response = await api.get(endpoint, { responseType: 'arraybuffer' });
  return zipBlobFromResponse(response, fallbackName);
}

async function fetchDiagnosticArchive(options: DiagnosticExportOptions = {}): Promise<AuditArchive> {
  const pollIntervalMs = options.pollIntervalMs ?? diagnosticPollIntervalMs;
  const timeoutMs = options.timeoutMs ?? diagnosticTimeoutMs;
  const queuedStallMs = options.queuedStallMs ?? diagnosticQueuedStallMs;
  const wait = options.wait ?? ((milliseconds: number) => new Promise<void>((resolve) => {
    window.setTimeout(resolve, milliseconds);
  }));
  const now = options.now ?? Date.now;
  const created = await api.post('/admin/diagnostics/jobs', {});
  let job = diagnosticJobFromResponse(created.data);
  const jobPath = `/admin/diagnostics/jobs/${encodeURIComponent(job.id)}`;
  const startedAt = now();
  const deadline = startedAt + timeoutMs;
  let queuedSince = job.status === 'queued' ? startedAt : 0;

  while (job.status !== 'ready') {
    if (terminalDiagnosticStatuses.has(job.status)) {
      const suffix = job.error_code ? ` (${job.error_code})` : '';
      throw new Error(`Diagnostic export ${job.status}${suffix}.`);
    }
    if (!pendingDiagnosticStatuses.has(job.status)) {
      throw new Error('The server returned an unknown diagnostic job status.');
    }
    const checkedAt = now();
    if (job.status === 'queued') {
      if (!queuedSince) queuedSince = checkedAt;
      if (checkedAt - queuedSince >= queuedStallMs) {
        const listResponse = await api.get('/admin/diagnostics/jobs').catch(() => null);
        const queuedJobs = diagnosticJobsFromListResponse(listResponse?.data);
        const current = queuedJobs.find((candidate) => candidate.id === job.id);
        if (current && current.status !== 'queued') {
          job = current;
          queuedSince = 0;
          continue;
        }
        const anotherJobIsRunning = queuedJobs.some((candidate) => (
          candidate.id !== job.id && runningDiagnosticStatuses.has(candidate.status)
        ));
        if (anotherJobIsRunning || listResponse === null) {
          // This job is legitimately behind the single global renderer, or queue
          // health could not be confirmed. The overall deadline remains enforced.
          queuedSince = checkedAt;
        } else {
          await api.delete(jobPath).catch(() => undefined);
          throw new Error('Diagnostic export worker did not claim the queued job before the queue-stall deadline.');
        }
      }
    } else {
      queuedSince = 0;
    }
    if (checkedAt >= deadline) {
      await api.delete(jobPath).catch(() => undefined);
      throw new Error('Diagnostic export timed out.');
    }
    if (pollIntervalMs > 0) await wait(pollIntervalMs);
    const statusResponse = await api.get(jobPath);
    job = diagnosticJobFromResponse(statusResponse.data);
    if (job.id !== jobPath.slice(jobPath.lastIndexOf('/') + 1)) {
      throw new Error('The diagnostic job identity changed while polling.');
    }
  }

  const response = await api.get(`${jobPath}/download`, { responseType: 'arraybuffer' });
  return zipBlobFromResponse(response, diagnosticFallbackName);
}

export async function fetchAuditArchive(
  kind: AuditExportKind,
  diagnosticOptions: DiagnosticExportOptions = {},
): Promise<AuditArchive> {
  if (kind === 'diagnostics') return fetchDiagnosticArchive(diagnosticOptions);
  const definition = archiveDefinitions[kind];
  return fetchDirectArchive(definition.endpoint, definition.fallbackName);
}
