# 邮箱池、自动化注册与注册配置新旧版本兼容报告

日期：2026-08-01
基线：任务开始前工作区快照 `artifacts/registration-compat-20260801/baseline/source-before.tar.gz`

## 1. 问题与根因

| 范围 | 原问题 | 根因 | 影响 |
| --- | --- | --- | --- |
| 注册配置 | 旧键写入后不生效 | 配置反序列化只读取当前字段，未知旧键被静默忽略 | 升级后注册开关、并发、超时、分组、出口池和注册方式丢失 |
| 邮箱池 | 旧邮箱数据能看到但不能被注册流程消费 | 新 provider registry 未注册数据库邮箱池；状态词与导入 envelope 也发生过变化 | 自动注册报告 mailbox provider 缺失 |
| 旧注册 API | 旧控制台/脚本收到 410 | 邮箱注册与 Turbo 注册旧路由被整体下线 | 老客户端无法创建、查看、取消任务或读取配置 |
| 自动化策略 | 旧策略读取为空或字段回落默认值 | 只接受当前 map 结构和当前字段名 | 自动补池阈值、目标、引擎、身份方式和 provider 失效 |
| 前端契约 | 同一业务的旧 envelope 触发“无法识别的数据” | Zod 契约只覆盖当前响应结构，且没有旧端点回退 | 新前端连旧后端、旧数据连新前端均出现空白或错误态 |

本次采用适配器/兼容外观渐进修复，没有重写当前注册流水线，也没有修改现有账号、任务或邮箱主表的业务语义。

## 2. 兼容边界与优先级

统一优先级为：

1. 请求或设置中的当前规范字段；
2. 同一请求中的旧字段别名；
3. 当前数据库 setting；
4. 历史 setting / 旧配置块；
5. 启动配置与项目默认值。

因此旧配置会继续工作，而显式写入的新配置始终覆盖旧值。保存操作写入规范结构；需要维持旧控制台读回能力的位置同步写入旧 setting。历史 `plus` 自动化记录仅可解码，不展示、不新建、不执行，避免恢复已移除的支付能力。

## 3. 后端适配矩阵

### 3.1 启动配置

| 历史键 | 当前键 / 字段 | 转换 |
| --- | --- | --- |
| `email_registration_enabled` | `registration_enabled` | 布尔值兼容字符串/数字 |
| `email_registration_concurrency` | `registration_concurrency` | 正整数 |
| `email_registration_timeout_seconds` | `registration_timeout` | 秒数 |
| `email_registration_group` | `registration_default_group` | 去除首尾空白 |
| `email_registration_egress_pool_id` | `registration_egress_pool_id` | 原值保留 |
| `register_method` / `registration_method` | `default_register_method` | 引擎别名规范化 |

注册方式别名：`email` 系列映射到 `protocol_v2`，`turbo` / `turbo_gpt` / `playwright` 系列映射到 `browser_v3`。当前键存在时不读取对应旧键。

### 3.2 注册请求与设置

批量注册和 canary 共用同一解码器，兼容：

- `total` / `count`、字符串数字和当前整数；
- `method` / `engine` / `register_method`；
- `groupName` / `group_name`、`identity` / `identity_mode`；
- 旧出口池、短信、邮箱、域名和验证码 provider 字段；
- 顶层字段及旧版嵌套 `config`。

运行时开关、超时、默认分组、出口池及 provider 默认值从数据库设置热读取，避免服务启动后配置中心修改不生效。

### 3.3 邮箱池

- 新增数据库邮箱池 provider `email_pool`，通过原子状态变更占用一行；释放操作幂等。
- refresh token、密码和 access token 仅在服务端解密与使用，列表接口不返回这些字段。
- Outlook OAuth refresh 与 IMAP XOAUTH2 均有连接/响应上限；OTP 只从轮询结果中提取。
- 状态迁移：`ready/available` → `idle`，`busy/reserved` → `in_use`，`failed` → `error`，`consumed` → `used`。
- 导入支持数组、`accounts`、`email_accounts`、`rows/items/list`、`data/result/payload`，以及 tab、pipe、`----` 分隔的历史文本。
- 查询兼容 `page_size/per_page/limit`、`q/query/email`、`state/status`；删除兼容数组、对象和单 ID。

### 3.4 旧路由外观

| 旧路由族 | 当前行为 |
| --- | --- |
| `/admin/register/email/config` | 读取/保存规范配置并同步旧设置 |
| `/admin/register/email/start` | 翻译后进入统一注册 pipeline |
| `/admin/register/email/jobs`、`job/status`、`job/events`、`job/events/sse` | 从统一任务提供旧响应外观 |
| `/admin/register/email/job/{id}` | 取消统一任务 |
| `/admin/turbo-gpt-register/jobs` 及 job 子路由 | 保留旧草稿/推进/重试/token 契约，并桥接 `browser_v3` |
| `/admin/turbo-gpt-register/config` | 映射到当前规范设置 |

所有路由继续使用现有管理端权限检查。旧任务表保留用于可恢复的草稿和旧 ID 映射；新执行路径只有统一 pipeline 一份。

### 3.5 自动化策略

- 接受当前 map、数组和 `{ "policies": [...] }` envelope。
- `auto-refill`、`pool-refill` 等旧类型规范化为 `refill`。
- 目标、阈值、间隔、引擎、身份、分组、出口池、短信/邮箱/验证码 provider 均支持 snake_case 和 camelCase 别名。
- 保存时只写规范字段；scheduler 仅运行当前支持的策略类型。

## 4. 前端兼容层

- 邮箱池：兼容 `email_accounts/emailAccounts/rows/items/list`、嵌套 envelope、旧分页和状态统计；新 `idle` 展示“空闲”，旧 `ready/available` 保留“可用”文案，容量统计同时计入。
- 注册任务：兼容 `jobs/tasks/items/rows`、嵌套 `data/result/payload`、旧任务字段，以及历史空对象/元数据空响应。
- 注册 readiness、国家、分组、出口池、provider options 和配置中心响应均在 API 边界规范化，页面组件只消费统一模型。
- 当前端点返回 404/405/410/501 时，任务、provider、保存策略和启动任务分别回退到旧端点；业务错误不会被回退掩盖。
- 所有未知错误对象仍触发契约错误，不会伪装为空列表。

## 5. 风险控制与回滚

| 风险 | 控制 |
| --- | --- |
| 旧字段覆盖新配置 | 规范字段存在即优先，测试覆盖冲突输入 |
| 邮箱重复占用 | 事务内 `idle → in_use` 原子保留，释放幂等 |
| 密钥泄漏 | API 输出清洗；fingerprint 只使用数量/更新时间 |
| 旧路由形成第二套执行器 | 旧路由只做翻译与状态外观，执行统一进入当前 pipeline |
| 前端吞掉真实错误 | 仅已知空 envelope 归一为空；error/未知对象继续失败 |
| UI 长文本重叠 | 桌面表格硬裁切，移动端独立列表；真实浏览器逐组合扫描 |

任务产物中的 `rollback.sh` 只恢复本次快照差异，并先校验基线归档哈希。完整补丁、修改包、验证记录和回滚演练结果位于 `artifacts/registration-compat-20260801/`。

## 6. 验收依据

- Go 全量测试：所有包通过。
- Go vet：通过。
- 前端静态检查、类型检查、全部 Vitest 与生产构建：通过。
- 安装/升级安全：安装分派、有限备份和受管源码收敛通过。
- 浏览器 UI：注册页与邮箱池页在 1440×900、1280×720、390×844、360×800，浅色/深色共 16 组合通过；文字溢出、页面溢出、同级元素重叠、图表文字重叠和控件裁切均为 0。

字面输出、退出状态、截图、操作日志与哈希清单均保存在本任务验证目录，便于独立复核。
