# Registration compatibility modified source

This archive contains every source or embedded-console path changed by the
2026-08-01 registration compatibility task. It is a task delta, not a full
repository clone. Apply `delivery/registration-compat.patch` to the frozen
baseline for an independently replayable reconstruction.

The runnable Linux amd64 build is shipped beside this archive as
`codex-pool-server-linux-amd64`.
